select 'executing sql scripts';
